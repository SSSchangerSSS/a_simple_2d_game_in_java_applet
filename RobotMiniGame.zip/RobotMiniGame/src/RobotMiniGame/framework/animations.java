/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RobotMiniGame.framework;

import java.util.ArrayList;
import java.awt.Image;
/**
 *
 * @author fornumber
 */
public class animations {
    
    private ArrayList frames;
    private int currentFrame;
    private long animTime;
    private long totalDuration;
    
    public animations(){
    frames = new ArrayList();
    totalDuration = 0;
    
    synchronized(this){
    animTime = 0;
    currentFrame = 0;   
    }
    
    }
    
public synchronized void addFrame(Image image , long Duration){
    totalDuration += Duration; 
    frames.add(new animFrame(image,totalDuration));
}
    
public synchronized animFrame getFrame(int i){
return (animFrame)frames.get(i);    
}   

public synchronized Image getImage(){
    if(frames.size() == 0)
        return null;
    else
return getFrame(currentFrame).image;    
}

public synchronized void update(long elapsedTime){
  if(frames.size() > 1){
  animTime += elapsedTime;    
  if(animTime > totalDuration){
   animTime = animTime % totalDuration; 
   currentFrame = 0;
  }        
    
 while(animTime > getFrame(currentFrame).endTime){
  currentFrame++;   
 }
 
}  
}


private  class animFrame{

 long endTime;
 Image image;    
 public animFrame(Image image, long endTime){
 this.image = image;
 this.endTime = endTime;
 }   
    
    
}
}